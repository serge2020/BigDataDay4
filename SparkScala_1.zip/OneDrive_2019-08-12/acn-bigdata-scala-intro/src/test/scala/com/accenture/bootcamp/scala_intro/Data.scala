package com.accenture.bootcamp.scala_intro

object Data {

  val newYearHonours: Seq[String] = Loader.loadNewYearHonours()
  val australianTreaties: Seq[String] = Loader.loadAustralianTreaties()

}
