package com.accenture.bootcamp.scala_intro

import org.scalatest.{BeforeAndAfterAll, FunSuite, Matchers}

trait SparkSuite extends FunSuite with Matchers with BeforeAndAfterAll with Tasks{

}
