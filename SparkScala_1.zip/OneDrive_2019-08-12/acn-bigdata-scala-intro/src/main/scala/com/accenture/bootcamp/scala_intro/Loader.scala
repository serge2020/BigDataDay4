package com.accenture.bootcamp.scala_intro

import scala.io.{BufferedSource, Source}

object Loader {

  protected def using[A <: BufferedSource, B](src: A)(fn: A => B): B = {
    try {
      fn(src)
    } finally {
      src.close()
    }
  }

  protected def usingLines[A <: BufferedSource](src: A): Seq[String] = using(src)(_.getLines().toVector)

  protected def fromResource(resource: String): BufferedSource = {
    Source.fromFile("src/test/resources/" + resource)
  }

  lazy val newYearHonours: Seq[String] = usingLines(fromResource("1918NewYearHonours.txt"))
  lazy val australianTreaties: Seq[String] = usingLines(fromResource("ListOfAustralianTreaties.txt"))

  def loadNewYearHonours(): Seq[String] = newYearHonours


  def loadAustralianTreaties(): Seq[String] = australianTreaties


}
